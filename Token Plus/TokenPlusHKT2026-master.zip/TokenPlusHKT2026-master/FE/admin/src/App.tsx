import { startPolling } from "@/lib/polling"
import { useEffect, useRef, useState } from "react"
import { Check, X } from "lucide-react"
import Topbar from "@/components/layout/Topbar"
import IconButton from "@/components/ui/IconButton"
import Sidebar from "@/components/layout/Sidebar"
import OverviewPage from "@/components/pages/OverviewPage"
import MapPage from "@/components/pages/MapPage"
import ReportsPage from "@/components/pages/ReportsPage"
import UsersPage from "@/components/pages/UsersPage"
import AnalyticsPage from "@/components/pages/AnalyticsPage"
import ReportReviewModal from "@/components/reports/ReportReviewModal"
import ConfirmDialog from "@/components/ui/ConfirmDialog"
import UserDetailModal from "@/components/users/UserDetailModal"
import {
  approveReportApi,
  buildRealtimeAdminMapPoints,
  fetchAdminInitialData,
  fetchCurrentWeatherApi,
  fetchUsersCsvBlob,
  rejectReportApi,
  subscribeAdminRealtime,
  syncWeatherForecastsApi,
  toggleReportLockApi,
  updateUserStatusApi,
} from "@/lib/api"
import type {
  AreaAlert,
  CommunityUser,
  FloodReport,
  MapLayer,
  MapPoint,
  Page,
  Severity,
  TrendsMap,
  UserStatus,
  WeatherSnapshot,
} from "@/types"

const EMPTY_TRENDS: TrendsMap = {
  "24h": { labels: [], reports: [], rain: [], insight: "Chưa có dữ liệu xu hướng" },
  "7d": { labels: [], reports: [], rain: [], insight: "Chưa có dữ liệu xu hướng" },
  "30d": { labels: [], reports: [], rain: [], insight: "Chưa có dữ liệu xu hướng" },
}

export default function App() {
  const [reports, setReports] = useState<FloodReport[]>([])
  const [alerts, setAlerts] = useState<AreaAlert[]>([])
  const [mapPoints, setMapPoints] = useState<MapPoint[]>(() =>
    buildRealtimeAdminMapPoints([], [], null),
  )
  const [trendsData, setTrendsData] = useState<TrendsMap>(EMPTY_TRENDS)
  const [weather, setWeather] = useState<WeatherSnapshot | null>(null)
  const [isLiveBackend, setIsLiveBackend] = useState(false)
  const [selectedMapPoint, setSelectedMapPoint] = useState<string | null>(null)
  const [layers, setLayers] = useState<MapLayer[]>([
    "flood",
    "risk",
    "rain",
    "history",
  ])
  const [severityFilter, setSeverityFilter] = useState<"all" | Severity>("all")
  const [trendRange, setTrendRange] = useState<keyof TrendsMap>("24h")
  const [reviewing, setReviewing] = useState<FloodReport | null>(null)
  const [rejecting, setRejecting] = useState<FloodReport | null>(null)
  const [toast, setToast] = useState<string | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [page, setPage] = useState<Page>("overview")
  const [users, setUsers] = useState<CommunityUser[]>([])
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null)

  const dataRevision = useRef(0)

  useEffect(() => {
    let active = true
    async function loadInitial() {
      const revision = dataRevision.current
      const data = await fetchAdminInitialData()
      if (!active || revision !== dataRevision.current || !data.live) return
      if (Array.isArray(data.reports)) {
        setReports(data.reports)
      }
      if (Array.isArray(data.alerts)) {
        setAlerts(data.alerts)
      }
      if (Array.isArray(data.mapPoints)) {
        setMapPoints(data.mapPoints)
      }
      if (Array.isArray(data.users)) {
        setUsers(data.users)
      }
      if (data.trends && typeof data.trends === "object") {
        setTrendsData((prev) => ({
          "24h":
            data.trends?.["24h"]?.labels?.length
              ? data.trends["24h"]
              : prev["24h"],
          "7d":
            data.trends?.["7d"]?.labels?.length
              ? data.trends["7d"]
              : prev["7d"],
          "30d":
            data.trends?.["30d"]?.labels?.length
              ? data.trends["30d"]
              : prev["30d"],
        }))
      }
      if (data.weather) setWeather(data.weather)
      setIsLiveBackend(true)
    }
    const stopPolling = startPolling(loadInitial)

    const unsubscribe = subscribeAdminRealtime({
      onReportCreated: ({ report, mapPoint }) => {
        if (!active) return
        dataRevision.current++
        setReports((current) =>
          current.some((r) => r.id === report.id)
            ? current
            : [report, ...current],
        )
        if (mapPoint) {
          setMapPoints((current) =>
            current.some((pt) => pt.id === mapPoint.id)
              ? current
              : [...current, mapPoint],
          )
        }
        setToast(
          `Realtime: Báo cáo mới ${report.id} tại ${report.location} vừa được gửi.`,
        )
      },
      onReportApproved: ({ report, updatedMapPoint }) => {
        if (!active) return
        dataRevision.current++
        setReports((current) =>
          current.map((item) => (item.id === report.id ? report : item)),
        )
        if (updatedMapPoint) {
          setMapPoints((current) =>
            current.map((pt) =>
              pt.linkedReportId === report.id ? updatedMapPoint : pt,
            ),
          )
        }
      },
      onReportRejected: ({ report }) => {
        if (!active) return
        dataRevision.current++
        setReports((current) =>
          current.map((item) => (item.id === report.id ? report : item)),
        )
      },
      onAlertCreated: (alert) => {
        if (!active) return
        dataRevision.current++
        setAlerts((current) =>
          current.some((a) => a.id === alert.id)
            ? current
            : [alert, ...current],
        )
      },
      onAlertUpdated: (alert) => {
        if (!active) return
        dataRevision.current++
        setAlerts((current) =>
          current.map((a) => (a.id === alert.id ? alert : a)),
        )
      },
      onAlertEnded: (alert) => {
        if (!active) return
        dataRevision.current++
        setAlerts((current) =>
          current.map((a) => (a.id === alert.id ? alert : a)),
        )
      },
      onWeatherUpdated: ({ snapshot }) => {
        if (!active) return
        dataRevision.current++
        if (snapshot) setWeather(snapshot)
      },
      onUserUpdated: ({ action, user }) => {
        if (!active || !user) return
        dataRevision.current++
        setUsers((current) => {
          const exists = current.some((u) => u.id === user.id)
          if (exists) {
            return current.map((u) => (u.id === user.id ? user : u))
          }
          return [user, ...current]
        })
        if (action === "registered") {
          setToast(
            `Realtime: Người dùng mới ${user.name} (${user.district}) vừa đăng ký tài khoản!`,
          )
        }
      },
    })

    return () => {
      active = false
      stopPolling()
      unsubscribe()
    }
  }, [])

  useEffect(() => {
    if (!toast) return
    const timer = window.setTimeout(() => setToast(null), 3200)
    return () => window.clearTimeout(timer)
  }, [toast])

  const liveReportsCount = reports.filter(
    (report) => report.status === "verified",
  ).length
  const activeAlertCount = alerts.filter(
    (alert) => alert.status === "active",
  ).length

  const navigate = (next: Page) => {
    setPage(next)
    setSidebarOpen(false)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const selectMapPoint = (point: MapPoint) => {
    if (selectedMapPoint === point.id) {
      setSelectedMapPoint(null)
      return
    }
    setSelectedMapPoint(point.id)
    if (point.linkedReportId) {
      const report = reports.find(
        (item) => item.id === point.linkedReportId,
      )
      if (report) setReviewing(report)
    }
  }

  const handleSyncWeather = async () => {
    await syncWeatherForecastsApi()
    const freshWeather = await fetchCurrentWeatherApi()
    if (freshWeather) {
      setWeather(freshWeather)
      setToast(
        `Đã đồng bộ thời tiết từ Open-Meteo: ${freshWeather.weatherCondition} · ${Math.round(freshWeather.temperatureC)}°C.`,
      )
    }
  }

  const approveReport = async () => {
    if (!reviewing) return
    const targetId = reviewing.id
    const apiResult = await approveReportApi(targetId)
    dataRevision.current++
    setReports((current) =>
      current.map((report) =>
        report.id === targetId
          ? apiResult?.report ?? { ...report, status: "verified" }
          : report,
      ),
    )
    if (apiResult?.updatedMapPoint) {
      setMapPoints((current) => {
        const exists = current.some((pt) => pt.linkedReportId === targetId)
        if (exists) {
          return current.map((pt) =>
            pt.linkedReportId === targetId ? apiResult.updatedMapPoint! : pt,
          )
        }
        return [...current, apiResult.updatedMapPoint!]
      })
    }
    setReviewing(null)
    setToast(`Đã mở khóa báo cáo ${targetId} và hiển thị lại trên bản đồ.`)
  }

  const rejectReport = async (reason?: string) => {
    if (!rejecting) return
    const targetId = rejecting.id
    const apiResult = await rejectReportApi(targetId, reason)
    dataRevision.current++
    setReports((current) =>
      current.map((report) =>
        report.id === targetId
          ? apiResult?.report ?? { ...report, status: "rejected" }
          : report,
      ),
    )
    setMapPoints((current) =>
      current.filter((point) => point.linkedReportId !== targetId),
    )
    setRejecting(null)
    setReviewing(null)
    setToast(
      `Đã khóa báo cáo ${targetId}${reason ? `: ${reason}` : ""} và ẩn khỏi bản đồ.`,
    )
  }

  const handleToggleLock = async (report: FloodReport) => {
    const apiResult = await toggleReportLockApi(report.id)
    dataRevision.current++
    if (apiResult?.report) {
      setReports((current) =>
        current.map((r) => (r.id === report.id ? apiResult.report : r)),
      )
    }
    if (apiResult?.updatedMapPoint) {
      setMapPoints((current) => {
        const exists = current.some((pt) => pt.linkedReportId === report.id)
        if (exists) {
          return current.map((pt) =>
            pt.linkedReportId === report.id ? apiResult.updatedMapPoint! : pt,
          )
        }
        return [...current, apiResult.updatedMapPoint!]
      })
    } else if (apiResult?.report?.status === "rejected") {
      setMapPoints((current) =>
        current.filter((pt) => pt.linkedReportId !== report.id),
      )
    }
    const isLocked = (apiResult?.report?.status ?? report.status) === "rejected"
    setToast(
      isLocked
        ? `Đã khóa báo cáo ${report.id} (${report.location}) và ẩn khỏi bản đồ.`
        : `Đã mở khóa báo cáo ${report.id} (${report.location}) và hiển thị lại trên bản đồ.`,
    )
  }

  const hiddenReportIds = new Set(
    reports.filter((report) => report.status === "rejected").map((report) => report.id),
  )
  const visibleMapPoints = mapPoints.filter(
    (point) => !point.linkedReportId || !hiddenReportIds.has(point.linkedReportId),
  )

  const selectedUser = users.find((user) => user.id === selectedUserId) ?? null

  const exportUsers = async () => {
    const backendBlob = await fetchUsersCsvBlob()
    if (backendBlob) {
      const url = URL.createObjectURL(backendBlob)
      const link = document.createElement("a")
      link.href = url
      link.download = "saigondrain-nguoi-dung.csv"
      link.click()
      window.setTimeout(() => URL.revokeObjectURL(url), 1000)
      setToast("Đã xuất danh sách người dùng từ Backend ra tệp CSV.")
      return
    }

    const statusLabel: Record<UserStatus, string> = {
      active: "Hoạt động",
      review: "Cần xem xét",
      blocked: "Đã khóa",
    }
    const header = [
      "Mã người dùng",
      "Họ tên",
      "Khu vực",
      "Báo cáo",
      "Đã xác minh",
      "Từ chối",
      "Điểm tin cậy",
      "Xác thực",
      "Trạng thái",
      "Hoạt động cuối",
    ]
    const rows = users.map((user) => [
      user.id,
      user.name,
      user.district,
      String(user.reports),
      String(user.verifiedReports),
      String(user.rejectedReports),
      String(user.trustScore),
      user.identityVerified ? "Đã xác thực" : "Chưa xác thực",
      statusLabel[user.status],
      user.lastActive,
    ])
    const csv = [header, ...rows]
      .map((row) =>
        row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(","),
      )
      .join("\r\n")
    const blob = new Blob([`\uFEFF${csv}`], {
      type: "text/csv;charset=utf-8;",
    })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = "saigondrain-nguoi-dung.csv"
    link.click()
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
    setToast("Đã xuất danh sách người dùng ra tệp CSV.")
  }

  const updateUserStatus = async (status: UserStatus) => {
    if (!selectedUser) return
    const targetId = selectedUser.id
    const updatedUser = await updateUserStatusApi(targetId, status)
    dataRevision.current++
    setUsers((current) =>
      current.map((user) =>
        user.id === targetId ? (updatedUser ?? { ...user, status }) : user,
      ),
    )
    setToast(
      status === "blocked"
        ? `Đã khóa tài khoản ${targetId}.`
        : status === "review"
          ? `Đã chuyển ${targetId} vào danh sách xem xét.`
          : `Đã mở khóa tài khoản ${targetId}.`,
    )
    setSelectedUserId(null)
  }

  return (
    <div className="app-shell">
      <Sidebar
        activeAlertCount={activeAlertCount}
        onNavigate={navigate}
        open={sidebarOpen}
        page={page}
        pendingCount={liveReportsCount}
        setOpen={setSidebarOpen}
      />
      <main className="main">
        <Topbar
          onViewReports={() => navigate("reports")}
          onExportUsers={exportUsers}
          onOpenMenu={() => setSidebarOpen(true)}
          onSyncWeather={handleSyncWeather}
          page={page}
          weather={weather}
        />

        <div className="content">
          {page === "overview" && (
            <OverviewPage
              layers={layers}
              onNavigate={navigate}
              onReview={setReviewing}
              onSelectPoint={selectMapPoint}
              points={visibleMapPoints}
              reports={reports}
              selectedMapPoint={selectedMapPoint}
              setLayers={setLayers}
              setSeverityFilter={setSeverityFilter}
              setTrendRange={setTrendRange}
              severityFilter={severityFilter}
              trendRange={trendRange}
              trendsData={trendsData}
              users={users}
              weather={weather}
            />
          )}
          {page === "map" && (
            <MapPage
              layers={layers}
              onSelectPoint={selectMapPoint}
              points={visibleMapPoints}
              reports={reports}
              selectedMapPoint={selectedMapPoint}
              setLayers={setLayers}
              setSeverityFilter={setSeverityFilter}
              severityFilter={severityFilter}
            />
          )}
          {page === "reports" && (
            <ReportsPage
              onReview={setReviewing}
              onToggleLock={handleToggleLock}
              points={visibleMapPoints}
              reports={reports}
            />
          )}
          
          {page === "users" && (
            <UsersPage
              onSelect={(user) => setSelectedUserId(user.id)}
              users={users}
            />
          )}
          {page === "analytics" && (
            <AnalyticsPage
              alerts={alerts}
              points={visibleMapPoints}
              reports={reports}
              setTrendRange={setTrendRange}
              trendRange={trendRange}
              trendsData={trendsData}
              users={users}
            />
          )}

          <footer className="page-footer">
            <span>SaigonDrain AI · Trung tâm điều hành đô thị thông minh</span>
          </footer>
        </div>
      </main>

      {reviewing && (
        <ReportReviewModal
          report={reviewing}
          reports={reports}
          onClose={() => setReviewing(null)}
          onApprove={approveReport}
          onReject={() => {
            setRejecting(reviewing)
            setReviewing(null)
          }}
        />
      )}
      {rejecting && (
        <ConfirmDialog
          title="Khóa báo cáo hiện trường?"
          description={`Báo cáo ${rejecting.id} tại "${rejecting.location}" sẽ bị khóa và ẩn khỏi bản đồ công khai TP.HCM. Bạn có thể mở khóa lại bất kỳ lúc nào.`}
          confirmLabel="Khóa báo cáo (Ẩn khỏi bản đồ)"
          onClose={() => setRejecting(null)}
          onConfirm={rejectReport}
          withReason
        />
      )}
      {selectedUser && (
        <UserDetailModal
          user={selectedUser}
          onClose={() => setSelectedUserId(null)}
          onStatusChange={updateUserStatus}
        />
      )}
      {toast && (
        <div className="toast" role="status" aria-live="polite">
          <span>
            <Check size={16} />
          </span>
          {toast}
          <IconButton label="Đóng thông báo" onClick={() => setToast(null)}>
            <X size={14} />
          </IconButton>
        </div>
      )}
    </div>
  )
}
