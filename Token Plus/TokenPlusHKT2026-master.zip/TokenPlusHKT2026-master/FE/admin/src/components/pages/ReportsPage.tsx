import { useMemo, useState } from "react"
import {
  ChevronDown,
  Clock3,
  Lock,
  Search,
  ShieldCheck,
  Sparkles,
  Unlock,
} from "lucide-react"
import Button from "@/components/ui/Button"
import EmptyState from "@/components/ui/EmptyState"
import SectionHeader from "@/components/ui/SectionHeader"
import SegmentedControl from "@/components/ui/SegmentedControl"
import StatusPill from "@/components/ui/StatusPill"
import { severityLabel } from "@/lib/severity"
import { reportStatusCounts } from "@/lib/analytics"
import CommunityReportsMap from "@/components/reports/CommunityReportsMap"
import type { FloodReport, MapPoint, ReportStatus, Severity } from "@/types"

const HCMC_ADMIN_DISTRICTS = [
  "Quận 1",
  "Quận 3",
  "Quận 4",
  "Quận 5",
  "Quận 6",
  "Quận 7",
  "Quận 8",
  "Quận 10",
  "Quận 11",
  "Quận 12",
  "Bình Thạnh",
  "Gò Vấp",
  "Phú Nhuận",
  "Tân Bình",
  "Tân Phú",
  "Bình Tân",
  "TP. Thủ Đức",
  "Củ Chi",
  "Hóc Môn",
  "Bình Chánh",
  "Nhà Bè",
  "Cần Giờ",
]

const severityTone: Record<Severity, "danger" | "watch" | "neutral"> = {
  critical: "danger",
  high: "watch",
  medium: "neutral",
}

const statusTone: Record<
  ReportStatus,
  "watch" | "safe" | "neutral"
> = {
  pending: "watch",
  verified: "safe",
  rejected: "neutral",
}

const statusLabel: Record<ReportStatus, string> = {
  pending: "Chờ duyệt",
  verified: "⚡ Đang hiển thị (AI duyệt)",
  rejected: "🔒 Đã khóa / Ẩn",
}

function ReportsPage({
  reports,
  points = [],
  onReview,
  onToggleLock,
}: {
  reports: FloodReport[]
  points?: MapPoint[]
  onReview: (report: FloodReport) => void
  onToggleLock?: (report: FloodReport) => void
}) {
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null)
  const [status, setStatus] = useState<"all" | ReportStatus>("all")
  const [severity, setSeverity] = useState<"all" | Severity>("all")
  const [district, setDistrict] = useState("all")
  const [timeRange, setTimeRange] = useState<"all" | "today" | "3d" | "7d">("all")
  const [query, setQuery] = useState("")

  const allDistricts = useMemo(() => {
    const reportDistricts = reports.map((report) => report.district).filter(Boolean)
    const set = new Set([...HCMC_ADMIN_DISTRICTS, ...reportDistricts])
    return Array.from(set).sort((a, b) => a.localeCompare(b, "vi"))
  }, [reports])

  const counts = reportStatusCounts(reports)

  const filtered = reports.filter((report) => {
    const matchesStatus = status === "all" || report.status === status
    const matchesSeverity =
      severity === "all" || report.severity === severity
    const matchesDistrict =
      district === "all" || report.district === district
    const matchesTime =
      timeRange === "all"
        ? true
        : timeRange === "today"
          ? report.minutesAgo <= 1440
          : timeRange === "3d"
            ? report.minutesAgo <= 4320
            : report.minutesAgo <= 10080
    const matchesQuery = `${report.id} ${report.location} ${report.district} ${report.description}`
      .toLowerCase()
      .includes(query.trim().toLowerCase())
    return (
      matchesStatus &&
      matchesSeverity &&
      matchesDistrict &&
      matchesTime &&
      matchesQuery
    )
  })

  return (
    <div className="page-stack">
      <SectionHeader
        description="Báo cáo được AI Gemini thẩm định và tự động duyệt lên bản đồ. Admin có thể xem chi tiết hoặc khóa báo cáo."
        title="Quản lý báo cáo cộng đồng"
      />

      <div className="report-stat-row">
        <div className="report-stat">
          <Sparkles size={18} style={{ color: "#10b981" }} />
          <div>
            <strong>{counts.verified}</strong>
            <span>AI tự động duyệt</span>
          </div>
        </div>
        <div className="report-stat">
          <Lock size={18} style={{ color: "#ef4444" }} />
          <div>
            <strong>{counts.rejected}</strong>
            <span>Đã khóa / Ẩn</span>
          </div>
        </div>
        <div className="report-stat">
          <Clock3 size={18} style={{ color: "#f59e0b" }} />
          <div>
            <strong>{counts.pending}</strong>
            <span>Chờ duyệt</span>
          </div>
        </div>
        <div className="report-stat">
          <ShieldCheck size={18} />
          <div>
            <strong>{counts.total}</strong>
            <span>Tổng báo cáo</span>
          </div>
        </div>
      </div>

      {/* Bản đồ Giám sát Điểm ngập do Người dân báo cáo - Admin có quyền Khóa / Mở */}
      <CommunityReportsMap
        reports={reports}
        selectedReportId={selectedReportId}
        onSelectReport={(r) => setSelectedReportId(r ? r.id : null)}
        onToggleLock={(r) => {
          if (onToggleLock) {
            onToggleLock(r)
          } else {
            onReview(r)
          }
        }}
        onReview={onReview}
      />

      <section className="panel">
        <div className="reports-toolbar">
          <SegmentedControl
            label="Lọc theo trạng thái"
            onChange={setStatus}
            options={[
              { value: "all", label: "Tất cả" },
              { value: "verified", label: "⚡ Đang hiển thị" },
              { value: "rejected", label: "🔒 Đã khóa" },
              { value: "pending", label: "Chờ duyệt" },
            ]}
            value={status}
          />
          <div className="user-filters">
            <label className="search-field">
              <Search size={16} />
              <input
                aria-label="Tìm báo cáo theo mã, đường hoặc quận"
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Tìm mã, đường, quận..."
                value={query}
              />
            </label>
            <label className="compact-select">
              <span className="sr-only">Lọc mức độ</span>
              <select
                onChange={(event) =>
                  setSeverity(event.target.value as "all" | Severity)
                }
                value={severity}
              >
                <option value="all">Tất cả mức độ</option>
                <option value="critical">Nghiêm trọng</option>
                <option value="high">Cao</option>
                <option value="medium">Trung bình</option>
              </select>
              <ChevronDown size={15} />
            </label>
            <label className="compact-select">
              <span className="sr-only">Lọc quận</span>
              <select
                onChange={(event) => setDistrict(event.target.value)}
                value={district}
              >
                <option value="all">Tất cả quận ({allDistricts.length})</option>
                {allDistricts.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
              <ChevronDown size={15} />
            </label>
            <label className="compact-select">
              <span className="sr-only">Lọc thời gian</span>
              <select
                onChange={(event) =>
                  setTimeRange(
                    event.target.value as "all" | "today" | "3d" | "7d",
                  )
                }
                value={timeRange}
              >
                <option value="all">Mọi thời gian</option>
                <option value="today">24 giờ qua</option>
                <option value="3d">3 ngày qua</option>
                <option value="7d">7 ngày qua</option>
              </select>
              <ChevronDown size={15} />
            </label>
          </div>
        </div>

        {filtered.length ? (
          <div className="table-wrap">
            <table className="data-table reports-table">
              <caption className="sr-only">
                Danh sách báo cáo cộng đồng, {filtered.length} báo cáo
              </caption>
              <thead>
                <tr>
                  <th>Hiện trường</th>
                  <th>Quận</th>
                  <th>Mức độ</th>
                  <th>Mực nước AI</th>
                  <th>Thời gian</th>
                  <th>Trạng thái</th>
                  <th>
                    <span className="sr-only">Thao tác</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((report) => (
                  <tr key={report.id}>
                    <td data-label="Hiện trường">
                      <strong>{report.location}</strong>
                      <span className="cell-note">
                        {report.id} · {report.priority}
                      </span>
                    </td>
                    <td data-label="Quận">{report.district}</td>
                    <td data-label="Mức độ">
                      <StatusPill tone={severityTone[report.severity]}>
                        {severityLabel(report.severity)}
                      </StatusPill>
                    </td>
                    <td data-label="Mực nước AI">
                      <strong>{report.aiDepth} cm</strong>
                      <span className="cell-note">
                        {report.aiConfidence > 0
                          ? `AI tin cậy ${report.aiConfidence}%`
                          : "Người dân khai báo"}
                      </span>
                    </td>
                    <td data-label="Thời gian">
                      {report.minutesAgo} phút trước
                    </td>
                    <td data-label="Trạng thái">
                      <StatusPill tone={statusTone[report.status]}>
                        {statusLabel[report.status]}
                      </StatusPill>
                    </td>
                    <td data-label="Thao tác" style={{ whiteSpace: "nowrap" }}>
                      <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
                        {report.status === "rejected" ? (
                          <Button
                            variant="secondary"
                            onClick={(e) => {
                              e.stopPropagation()
                              if (onToggleLock) onToggleLock(report)
                              else onReview(report)
                            }}
                          >
                            <Unlock size={13} /> Mở khóa
                          </Button>
                        ) : report.status === "pending" ? (
                          <>
                            <Button
                              variant="primary"
                              onClick={(e) => {
                                e.stopPropagation()
                                if (onToggleLock) onToggleLock(report)
                                else onReview(report)
                              }}
                              title="Duyệt và mở hiển thị lên bản đồ cộng đồng"
                            >
                              <Sparkles size={13} /> Duyệt & Mở
                            </Button>
                            <Button
                              variant="danger"
                              onClick={(e) => {
                                e.stopPropagation()
                                onReview(report)
                              }}
                              title="Khóa / Từ chối"
                            >
                              <Lock size={13} /> Khóa
                            </Button>
                          </>
                        ) : (
                          <Button
                            variant="danger"
                            onClick={(e) => {
                              e.stopPropagation()
                              if (onToggleLock) onToggleLock(report)
                              else onReview(report)
                            }}
                          >
                            <Lock size={13} /> Khóa
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation()
                            setSelectedReportId(report.id)
                          }}
                          title="Xem vị trí trên bản đồ"
                        >
                          Xem vị trí
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            description="Thử thay đổi từ khóa hoặc bộ lọc mức độ, quận, thời gian."
            icon={<Search size={24} />}
            title="Không có báo cáo phù hợp"
          />
        )}
      </section>
    </div>
  )
}

export default ReportsPage
